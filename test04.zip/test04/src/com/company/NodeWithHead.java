package com.company;


/**
 * Created by hackeru on 2/16/2017.
 */
public class NodeWithHead {

    Node value;
    NodeWithHead next;

    public NodeWithHead(Node value){
        this.value = value;
    }
}
